"""Exact finite-state induction certificate for gamma^L_1(S(P3,n)).

Pure Python 3.10+, standard library. No solver. State meanings:
0 selected=0, locally undominated (requires external selected neighbor)
1 selected=0, already dominated within subgraph
2 selected=1, has zero unselected neighbors within subgraph
3 selected=1, has one unselected neighbor within subgraph

All constraints for non-boundary vertices are fully satisfied.
The three boundary vertices of S(P3,n) are constant words 0^n, 1^n, 2^n.
"""
from itertools import product
from hashlib import sha256


def base():
    result = {}
    neighbors = ((1,), (0, 2), (1,))
    for chosen in product((0, 1), repeat=3):
        states = []
        for v in range(3):
            if chosen[v]:
                outside = sum(not chosen[w] for w in neighbors[v])
                if outside > 1:
                    break
                states.append(2 + outside)
            else:
                states.append(int(any(chosen[w] for w in neighbors[v])))
        else:
            result[tuple(states)] = sum(chosen)
    return result


def add_bridge(s, u, v):
    t = list(s)
    for i, j in ((u, v), (v, u)):
        if t[i] >= 2 and t[j] < 2:
            t[i] += 1
            if t[i] > 3:
                return None
        elif t[i] < 2 and t[j] >= 2:
            t[i] = 1
    return t


def transform(old):
    result = {}
    # Child state indices: 0-2 in copy0, 3-5 in copy1, 6-8 in copy2.
    # Added bridges: (copy0, boundary 1)--(copy1, boundary 0),
    #                (copy1, boundary 2)--(copy2, boundary 1).
    # Parent boundaries are child0-boundary0, child1-boundary1, child2-boundary2.
    boundary = (0, 4, 8)
    for triple in product(old, repeat=3):
        states = list(triple[0] + triple[1] + triple[2])
        for u, v in ((1, 3), (5, 7)):
            states = add_bridge(states, u, v)
            if states is None:
                break
        if states is None:
            continue
        if any(states[i] == 0 for i in range(9) if i not in boundary):
            continue
        parent_state = tuple(states[i] for i in boundary)
        value = sum(old[s] for s in triple)
        if value < result.get(parent_state, 10**100):
            result[parent_state] = value
    return result


def encode(table):
    return '\n'.join(''.join(map(str, k)) + ':' + str(table[k]) for k in sorted(table)) + '\n'


def verify():
    d1 = base()
    d2 = transform(d1)
    d3 = transform(d2)
    d4 = transform(d3)
    assert len(d1) == 7
    assert len(d2) == 36
    assert len(d3) == len(d4) == 64
    # ALL 64 states, not just the final optimal value:
    assert all(d4[s] == d3[s] + 36 for s in d3)
    delta = {s: d3[s] - 18 for s in d3}
    # Translate the table by a constant: T(d+c) = T(d)+3c.
    assert transform(delta) == delta
    assert min(delta[s] for s in delta if 0 not in s) == 0
    assert min(d1[s] for s in d1 if 0 not in s) == 2
    assert min(d2[s] for s in d2 if 0 not in s) == 6
    assert min(d3[s] for s in d3 if 0 not in s) == 18
    print('CERTIFICATE PASS: 64-state exact fixed point')
    print('n1 states:',len(d1),'n2:',len(d2),'n3:',len(d3))
    print('all 64 states: d4 - d3 = 36')
    print('T(delta)=delta: PASS')
    print('complete-state min(delta)=0')
    print('delta table SHA256:', sha256(encode(delta).encode()).hexdigest())
    print('FOR ALL n>=3: d_n(s)=2*3^(n-1)+delta(s)')
    print('THEREFORE gamma_1^L(S(P3,n))=2*3^(n-1) for n>=1')
    return delta


if __name__ == '__main__':
    table = verify()
    with open(__file__.rsplit('/',1)[0] + '/DELTA_TABLE.txt', 'w', encoding='utf-8') as f:
        f.write(encode(table))
