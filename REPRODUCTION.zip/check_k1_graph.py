"""Independent explicit word-graph validator; no finite-state DP imports."""
from itertools import product

def graph(n):
    words=list(product(range(3),repeat=n)); adj=[set() for _ in words]
    for i,u in enumerate(words):
        for j in range(i+1,len(words)):
            v=words[j]
            h=next((p for p in range(n) if u[p]!=v[p]),None)
            if h is None or abs(u[h]-v[h])!=1:continue
            if all(u[t]==v[h] and v[t]==u[h] for t in range(h+1,n)):
                adj[i].add(j);adj[j].add(i)
    return words,adj

def valid(D,adj,k):
    return all(i in D or (adj[i]&D) for i in range(len(adj))) and all(len(adj[i]-D)<=k for i in D)

for n in range(1,6):
    words,adj=graph(n)
    D=({0,2} if n==1 else {i for i,w in enumerate(words) if w[-2]!=w[-1]})
    assert len(D)==2*3**(n-1)
    assert valid(D,adj,1)
    assert sum(map(len,adj))//2==3**n-1
    if n<=2:
        optimum=min(len(T) for mask in range(1<<(3**n)) if valid((T:={i for i in range(3**n) if mask>>i&1}),adj,1))
        assert optimum==len(D)
    print('n=',n,'vertices=',len(words),'edges=',sum(map(len,adj))//2,'explicit construction=',len(D),'PASS')
