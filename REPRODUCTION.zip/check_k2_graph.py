"""Independent construction of S(P3,n) edges by direct word-pair definition.
Exhaustive k=2 domination for n<=2, structural assertions through n=7.
Uses no routines imported from author DP.
"""
from itertools import product
from collections import defaultdict


def graph(n):
    words=list(product(range(3), repeat=n))
    ids={w:i for i,w in enumerate(words)}
    adj=[set() for _ in words]
    for i,u in enumerate(words):
        for j in range(i+1,len(words)):
            v=words[j]
            h=next((k for k in range(n) if u[k]!=v[k]),None)
            if h is None or abs(u[h]-v[h]) != 1:continue
            if all(u[t]==v[h] and v[t]==u[h] for t in range(h+1,n)):
                adj[i].add(j);adj[j].add(i)
    return words,ids,adj


def selected_valid(adj, chosen, k):
    for i,nb in enumerate(adj):
        if i not in chosen and not (nb & chosen):return False
        if i in chosen and len(nb-chosen)>k:return False
    return True


def run(n):
    words,ids,adj=graph(n)
    N=len(words)
    assert sum(map(len,adj))//2==N-1
    seen={0};q=[0]
    for i in q:
        for j in adj[i]:
            if j not in seen:seen.add(j);q.append(j)
    assert len(seen)==N
    D={i for i,w in enumerate(words) if n>=2 and w[-2:] in ((0,1),(1,0),(1,2),(2,1))}
    if n>=2:
        assert len(D)==4*3**(n-2)
        assert selected_valid(adj,D,2)
        B=defaultdict(dict)
        for idx,w in enumerate(words):B[w[:-2]][w[-2:]]=idx
        for pre,block in B.items():
            L=[block[x] for x in ((0,0),(0,1),(0,2),(1,0))]
            R=[block[x] for x in ((2,0),(2,1),(2,2),(1,2))]
            center=block[(1,1)]
            # 11 is the only available cross-block compensator type
            assert len([v for v in adj[center] if words[v][:-2]!=pre])<=1
            # cross-block endpoints must have repeated last two digits
            for idx in block.values():
                for j in adj[idx]:
                    if words[j][:-2]!=pre:
                        assert words[idx][-2] == words[idx][-1]
                        assert words[j][-2] == words[j][-1]
    optimum=None
    if n<=2:
        for sz in range(N+1):
            for c in __import__('itertools').combinations(range(N),sz):
                if selected_valid(adj,set(c),2):optimum=sz;break
            if optimum is not None:break
        assert optimum==(1 if n==1 else 4)
    print('PASS',n,'nodes',N,'edges',N-1,'construction',len(D) if n>=2 else None,'brute',optimum)

if __name__=='__main__':
    for n in range(1,8):run(n)
