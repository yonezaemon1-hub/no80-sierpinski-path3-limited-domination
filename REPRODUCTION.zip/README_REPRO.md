# Reproduction (Python 3.10+, standard library only)

Run from this directory:

```bash
python verify_k1_finite_state.py
python check_k1_graph.py
python check_k2_graph.py
python verify_k1_k2_tree_dp.py
```

The finite-state checker overwrites `DELTA_TABLE.txt` in its current script directory; run on a disposable copy. It certifies the 64-state identity but is not a proof assistant. The last script is the historic tree-DP implementation **scoped to k=1,2 only**; a spurious historic k=3 diagnostic is intentionally omitted.

The separate original audit handoff archives are preserved outside the public upload set, in the private preparation folder for provenance. The public code does not constitute the independent auditor’s original C program.
