from itertools import product
from collections import Counter
INF=10**12

def edges(n):
  # index base-3 representation
  def rec(prefix,depth):
    if depth==0:return
    block=3**(depth-1)
    for j in range(3): yield from rec(prefix+j*block,depth-1)
    for j in range(2):
      # vertices (j,j+1 repeated), (j+1,j repeated)
      a=prefix+j*block+(j+1)*(block-1)//2
      b=prefix+(j+1)*block+j*(block-1)//2
      yield a,b
  return rec(0,n)

def solve(n,k):
  size=3**n
  adj=[[] for _ in range(size)]
  for u,v in edges(n):adj[u].append(v);adj[v].append(u)
  # states indexed selected vertex b, parent selected p
  parents=[-1]*size; order=[0]
  for u in order:
    for v in adj[u]:
      if v!=parents[u]:parents[v]=u;order.append(v)
  assert len(order)==size,(len(order),size)
  dp=[None]*size
  for u in reversed(order):
    ch=[v for v in adj[u] if v!=parents[u]]
    result=[[INF]*2 for _ in range(2)]
    for b in range(2):
      for p in range(2):
        for states in product((0,1),repeat=len(ch)):
          if b and (1-p+sum(1-x for x in states)>k):continue
          if not b and not (p or sum(states)>0):continue
          val=b+sum(dp[v][states[i]][b] for i,v in enumerate(ch))
          result[b][p]=min(result[b][p],val)
    dp[u]=result
  return min(dp[0][0][0],dp[0][1][0]),Counter(map(len,adj))

if __name__=='__main__':
 for n in range(1,10):
  print(n, [(k,solve(n,k)[0]) for k in (1,2)],flush=True)
